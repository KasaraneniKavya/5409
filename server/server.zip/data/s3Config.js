//name of bucket created using cloud formation
const bucketName = "csci5409-group42-2";
const region = "us-east-1";

module.exports = { bucketName, region };